/* Host syntax-check stub only; never flash this header to STM32. */
#ifndef STM32F1XX_HAL_H
#define STM32F1XX_HAL_H
#include <stdint.h>
typedef enum { HAL_OK = 0, HAL_ERROR = 1 } HAL_StatusTypeDef;
typedef struct { uint32_t ClockSpeed, DutyCycle, OwnAddress1, AddressingMode, DualAddressMode, OwnAddress2, GeneralCallMode, NoStretchMode; } I2C_InitTypeDef;
typedef struct { void *Instance; I2C_InitTypeDef Init; } I2C_HandleTypeDef;
typedef struct { uint32_t BaudRate, WordLength, StopBits, Parity, Mode, HwFlowCtl, OverSampling; } UART_InitTypeDef;
typedef struct { void *Instance; UART_InitTypeDef Init; } UART_HandleTypeDef;
typedef struct { uint32_t OscillatorType, HSEState, HSEPredivValue, HSIState, HSICalibrationValue; struct { uint32_t PLLState, PLLSource, PLLMUL; } PLL; } RCC_OscInitTypeDef;
typedef struct { uint32_t ClockType, SYSCLKSource, AHBCLKDivider, APB1CLKDivider, APB2CLKDivider; } RCC_ClkInitTypeDef;
typedef struct { uint32_t Pin, Mode, Pull, Speed; } GPIO_InitTypeDef;
#define I2C1 ((void *)1)
#define USART1 ((void *)2)
#define GPIOA ((void *)3)
#define GPIOB ((void *)4)
#define I2C_MEMADD_SIZE_8BIT 1
#define RCC_OSCILLATORTYPE_HSE 1
#define RCC_OSCILLATORTYPE_HSI 2
#define RCC_HSICALIBRATION_DEFAULT 16
#define RCC_HSE_ON 1
#define RCC_HSE_PREDIV_DIV1 1
#define RCC_HSI_ON 1
#define RCC_PLL_ON 1
#define RCC_PLLSOURCE_HSE 1
#define RCC_PLLSOURCE_HSI_DIV2 2
#define RCC_PLL_MUL9 1
#define RCC_PLL_MUL16 2
#define RCC_CLOCKTYPE_SYSCLK 1
#define RCC_CLOCKTYPE_HCLK 2
#define RCC_CLOCKTYPE_PCLK1 4
#define RCC_CLOCKTYPE_PCLK2 8
#define RCC_SYSCLKSOURCE_PLLCLK 1
#define RCC_SYSCLK_DIV1 1
#define RCC_HCLK_DIV2 2
#define RCC_HCLK_DIV1 1
#define FLASH_LATENCY_2 2
#define I2C_DUTYCYCLE_2 2
#define I2C_ADDRESSINGMODE_7BIT 1
#define I2C_DUALADDRESS_DISABLE 0
#define I2C_GENERALCALL_DISABLE 0
#define I2C_NOSTRETCH_DISABLE 0
#define UART_WORDLENGTH_8B 8
#define UART_STOPBITS_1 1
#define UART_PARITY_NONE 0
#define UART_MODE_TX_RX 3
#define UART_HWCONTROL_NONE 0
#define UART_OVERSAMPLING_16 16
#define GPIO_PIN_6 (1U << 6)
#define GPIO_PIN_7 (1U << 7)
#define GPIO_PIN_9 (1U << 9)
#define GPIO_PIN_10 (1U << 10)
#define GPIO_PIN_1 (1U << 1)
#define GPIO_PIN_2 (1U << 2)
#define GPIO_PIN_3 (1U << 3)
#define GPIO_PIN_11 (1U << 11)
#define GPIO_MODE_OUTPUT_PP 4
#define GPIO_SPEED_FREQ_LOW 0
typedef enum { GPIO_PIN_RESET = 0, GPIO_PIN_SET = 1 } GPIO_PinState;
#define GPIO_MODE_AF_OD 1
#define GPIO_MODE_AF_PP 2
#define GPIO_MODE_INPUT 3
#define GPIO_NOPULL 0
#define GPIO_SPEED_FREQ_HIGH 1
#define __HAL_RCC_GPIOA_CLK_ENABLE() ((void)0)
#define __HAL_RCC_GPIOB_CLK_ENABLE() ((void)0)
#define __HAL_RCC_AFIO_CLK_ENABLE() ((void)0)
#define __HAL_RCC_I2C1_CLK_ENABLE() ((void)0)
#define __HAL_RCC_USART1_CLK_ENABLE() ((void)0)
#define __HAL_AFIO_REMAP_I2C1_DISABLE() ((void)0)
#define __HAL_AFIO_REMAP_USART1_DISABLE() ((void)0)
#define __disable_irq() ((void)0)
HAL_StatusTypeDef HAL_I2C_Mem_Read(I2C_HandleTypeDef *, uint16_t, uint16_t, uint16_t, uint8_t *, uint16_t, uint32_t);
HAL_StatusTypeDef HAL_I2C_Mem_Write(I2C_HandleTypeDef *, uint16_t, uint16_t, uint16_t, uint8_t *, uint16_t, uint32_t);
HAL_StatusTypeDef HAL_I2C_IsDeviceReady(I2C_HandleTypeDef *, uint16_t, uint32_t, uint32_t);
uint32_t HAL_I2C_GetError(I2C_HandleTypeDef *);
uint32_t HAL_GetTick(void);
void HAL_Delay(uint32_t);
void HAL_Init(void);
HAL_StatusTypeDef HAL_RCC_OscConfig(RCC_OscInitTypeDef *);
HAL_StatusTypeDef HAL_RCC_ClockConfig(RCC_ClkInitTypeDef *, uint32_t);
HAL_StatusTypeDef HAL_I2C_Init(I2C_HandleTypeDef *);
HAL_StatusTypeDef HAL_UART_Init(UART_HandleTypeDef *);
HAL_StatusTypeDef HAL_UART_Transmit(UART_HandleTypeDef *, uint8_t *, uint16_t, uint32_t);
HAL_StatusTypeDef HAL_I2C_Master_Transmit(I2C_HandleTypeDef *, uint16_t, uint8_t *, uint16_t, uint32_t);
void HAL_GPIO_Init(void *, GPIO_InitTypeDef *);
void HAL_GPIO_WritePin(void *, uint16_t, GPIO_PinState);
#endif
