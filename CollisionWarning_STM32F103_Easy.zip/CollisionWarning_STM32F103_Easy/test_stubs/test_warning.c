/* Host-only unit tests: NOT for the STM32 firmware project. */
#include "warning.h"
#include <assert.h>
#include <stdio.h>

int main(void)
{
    Warning_Tracker tracker;
    Warning_Reset(&tracker);
    assert(tracker.state == WARNING_FAULT);

    Warning_Process(&tracker, 1400U, 100U);
    assert(tracker.state == WARNING_SAFE);
    assert(tracker.ttc_ms == WARNING_TTC_UNKNOWN);

    Warning_Process(&tracker, 1000U, 300U);
    Warning_Process(&tracker, 700U, 500U);
    Warning_Process(&tracker, 500U, 700U);
    assert(tracker.closing_mmps > 0);
    assert(tracker.ttc_ms != WARNING_TTC_UNKNOWN);

    Warning_Process(&tracker, 100U, 900U);
    Warning_Process(&tracker, 100U, 1100U);
    assert(tracker.state == WARNING_CRITICAL);

    Warning_Fault(&tracker);
    assert(tracker.state == WARNING_FAULT);
    assert(tracker.has_sample == 0U);
    Warning_Process(&tracker, 1400U, 5000U);
    assert(tracker.state == WARNING_SAFE);

    Warning_NoTarget(&tracker);
    assert(tracker.state == WARNING_NO_TARGET);
    assert(tracker.has_sample == 0U);
    assert(tracker.ttc_ms == WARNING_TTC_UNKNOWN);
    Warning_Process(&tracker, 800U, 5200U);
    assert(tracker.state == WARNING_SAFE);
    puts("warning algorithm: all tests passed");
    return 0;
}
