# Huong dan doc code canh bao va cham (ban de hoc)

Bo code nay dung STM32F103C8T6, VL53L0X, SSD1306, 3 LED, buzzer
va UART de xem qua Hercules. **Khong dung lam thiet bi an toan giao thong.**

## 1. Hoc theo thu tu nao?

Khong can doc 350 dong `vl53l0x.c` ngay tu dau! Hay di tu chuong trinh
chinh den tung driver:

1. **`main.c`**: chuong trinh lam gi theo thu tu?
2. **`warning.h`**: cac nguong 600 mm, 200 mm, TTC 3500/1500 ms.
3. **`warning.c`**: tu khoang cach suy ra toc do, TTC va 5 trang thai.
4. **`vl53l0x.h`**: biet cach goi 2 ham Init va ReadSingleMM.
5. **`vl53l0x.c`**: doc cac ham giao tiep I2C truoc, sau moi doc khoi tao.
6. **`ssd1306.h/.c`**: xem cach gui lenh, buffer va cap nhat OLED.

## 2. 3 lop cua he thong

| Lop | File | Nhiem vu |
| --- | --- | --- |
| Ung dung | `main.c` | Khoi tao; doc cam bien; dieu khien LED, buzzer, OLED, UART |
| Thuat toan | `warning.h/.c` | Quy tac canh bao, loc khoang cach, toc do, TTC |
| Driver | `vl53l0x.h/.c`, `ssd1306.h/.c` | Truyen/nhan byte voi cam bien va man hinh |

Chu y: CubeMX da sinh `SystemClock_Config`, `MX_I2C1_Init`,
`MX_USART1_UART_Init`, `MX_GPIO_Init`. **Khong tu y thay cac ham nay**.
`main.c` ban nay chi sua trong cac vung `USER CODE`.

## 3. Doc main.c tu tren xuong

**Cac `#define`**:

- `APP_SAMPLE_INTERVAL_MS = 200`: doc cam bien moi 200 ms.
- `APP_REPORT_INTERVAL_MS = 500`: gui Hercules moi 500 ms.
- `APP_OLED_INTERVAL_MS = 1000`: ve OLED moi 1 giay.
- `APP_SENSOR_RETRY_MS = 2000`: thu khoi tao lai khi driver loi.
- `MAX_DEMO_DISTANCE_MM = 2000`: pham vi minh hoa 2 m.

**Trong `main()`**, chu y 6 thao tac:

1. `HAL_Init()` va `SystemClock_Config()` — khoi tao STM32.
2. `MX_GPIO_Init()`, `MX_I2C1_Init()`, `MX_USART1_UART_Init()` — CubeMX.
3. `App_IO_Init()` — cau hinh PA1/2/3, PB11.
4. `SSD1306_Init()` va `VL53L0X_Init()` — khoi tao 2 module I2C.
5. `App_ReadSensor()` — lay `mm`, dua vao `warning.c` de phan loai.
6. `App_SetWarnings()`, `App_Report()`, `App_DrawOLED()` — hien thi va bao coi.

**`while(1)`** chay lien tuc; `HAL_GetTick()` giup kiem tra thoi gian,
khong can `HAL_Delay(200)` sau moi phep do. Cuoi vong co delay 10 ms.

## 4. Logic 5 trang thai

| Dieu kien | Trang thai | LED/coi |
| --- | --- | --- |
| I2C timeout/NACK, hoac mm < 20 | `WARNING_FAULT` | Do nhay 1 Hz, beep ngan |
| I2C thanh cong nhung mm > 2000 | `WARNING_NO_TARGET` | Xanh, tat coi; OLED NO TARGET |
| mm > 600 va TTC > 3500 (hoac khong biet TTC) | `WARNING_SAFE` | Xanh, tat coi |
| mm <= 600 hoac TTC <= 3500 | `WARNING_CAUTION` | Vang nhay, beep ngan |
| mm <= 200 hoac TTC <= 1500 | `WARNING_CRITICAL` | Do nhay nhanh, coi lien tuc |

Khi 2 dieu kien canh bao cung dung, muc **CRITICAL uu tien hon**.
`NO_TARGET` se xoa mau cu va toc do cu de lan sau tinh TTC lai tu dau.

**Gioi han:** Viec dung mm > 2000 de gan `NO TARGET` la quy uoc demo;
VL53L0X co the tra ve 8190/8191 khi khong do duoc. Ban driver gon nay
CHUA giai ma `RangeStatus` chuan cua ST. Khong duoc xem den xanh trong
truong hop `NO TARGET` la bang chung chac chan duong trong.

## 5. Warning_Process() tinh nhu the nao?

Vi du moi 200 ms, khoang cach giam 800 mm -> 700 mm:

1. Toc do tien lai gan xap xi `(800 - 700) / 0.2 = 500 mm/s`.
2. TTC xap xi `700 / 500 = 1.4 s`.
3. TTC <= 1.5 s => CRITICAL, cho du khoang cach dang > 200 mm.

Thuc te ham co bo loc EMA de giam nhieu:

`filtered_new = (3 * filtered_old + distance_new) / 4`.

Toc do duong nghia la vat can dang tien lai gan (khoang cach giam).
Neu toc do khong du lon, TTC bang `WARNING_TTC_UNKNOWN` va in `--`.

## 6. Doc driver `vl53l0x.c`: nho 3 tang

1. **Truyen byte:** `reg_read`, `reg_write` dung `HAL_I2C_Mem_Read/Write`.
2. **Thao tac thanh ghi:** `r8`, `w8`, `r16`, `w16` gom byte thanh so.
3. **Tac vu:** `VL53L0X_Init`, `VL53L0X_ReadSingleMM` goi cac ham tren.

Thu tu khoi tao: check I2C ACK -> check ID `0xEE` -> cau hinh SPAD
-> tuning -> calibration -> ready. Nhieu byte tuning theo thu vien
tham chieu ST/Pololu, khong the suy ra tu mot bang thanh ghi don gian;
de nguyen cho den khi ban hieu ro va test duoc tung buoc.

`VL53L0X_ReadSingleMM()` tra 2 gia tri khac nhau:

- `VL53L0X_Result`: ham co doc I2C thanh cong hay khong.
- `distance_mm`: ket qua mm (co the nam ngoai pham vi hop le).

Gia tri `raw_range_status` chi la byte thiet bi; KHONG phai
`RangeStatus` chuan ST API. Muon phan loai loi do do chinh xac, can
chuyen sang ST VL53L0X API hoac bo sung giai ma da kiem chung.

## 7. Test bang Hercules

Mo COM6 (hoac COM moi), 115200 8-N-1, CH340 RX -> PA9, GND chung.

1. Dat tam giay trang cach 80 cm: hien `SAFE`, LED xanh.
2. Dat cach 40 cm: `WARNING`, LED vang + beep ngan.
3. Dat cach 10 cm: `CRITICAL`, LED do + coi lien tuc.
4. Quay cam bien ve phia trong khong gian khong co vat gan: neu mm
   vuot 2000, se hien `[NO TARGET]`, LED xanh thay vi loi do.
5. Neu I2C hong: hien `[FAULT]` kem `step` va `I2C=...`, LED do nhay cham.

Neu khi khong co vat can van bao FAULT voi `raw=0mm`, **khong nen
ep mm=0 thanh an toan**. Hay gui dong Hercules de kiem tra tai sao
phep do khong hop le.

## 8. Dua vao Keil

1. Giu nguyen project CubeMX/Keil va sao luu `main.c` dang chay.
2. Chep file `.h` vao thu muc Include (`Core/Inc` hoac duong dan da khai bao).
3. Chep file `.c` vao `Core/Src`; them `vl53l0x.c`, `ssd1306.c`,
   `warning.c` vao Keil Project Items (moi file mot lan).
4. Thay `main.c` cua project bang `main.c` ban de hoc. Khong chep
   thu muc `test_stubs` vao Keil.
5. Build, nap ST-Link, mo Hercules. Thu lai 5 trang thai nhu tren.

**Cac gia tri trong bang la nguong demo, khong phai chung nhan an toan.**
