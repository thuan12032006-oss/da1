# STM32F103 + VL53L0X: Demo canh bao va cham

Bo ma nguon theo de cuong "Thiet ke va che tao bo mach nhung canh bao va cham".
Chu y: **CHI DE HOC VA THU NGHIEM TREN BAN; KHONG PHU HOP LAM HE THONG
AN TOAN VA CHAM THUC TE.**

## 1. Cac file

| File | Vai tro |
| --- | --- |
| `main.c` | Sao chep tu `main(5).c` do CubeMX sinh ra, chi them code vao cac vung `USER CODE`. |
| `vl53l0x.h` / `vl53l0x.c` | Driver VL53L0X ban dau cua ban: khoi tao + doc single shot (mm). |
| `ssd1306.h` / `ssd1306.c` | Driver OLED I2C 128x64, font ASCII don gian. |
| `warning.h` / `warning.c` | Loc EMA, tinh toc do, TTC va 5 trang thai (co NO TARGET). |
| `HUONG_DAN_DE_HOC.md` | Thu tu doc, sua va test code cho nguoi moi bat dau. |
| `test_stubs/` | Chi de test syntax tren PC; **KHONG** them vao Keil. |

Chuong trinh hien tai chay **superloop HAL, chua dung FreeRTOS** theo lo trinh
trong bao cao (RTOS du kien tich hop sau).

## 2. Dau noi va pin

| Thiet bi | STM32F103C8T6 |
| --- | --- |
| VL53L0X SCL + OLED SCL | PB6 (I2C1 SCL) |
| VL53L0X SDA + OLED SDA | PB7 (I2C1 SDA) |
| VL53L0X VIN, OLED VCC | Nguon 3.3V phu hop voi module dang dung |
| Tat ca GND | GND chung |
| LED xanh (+ qua dien tro 220R) | PA1; cuc (-) LED xuong GND |
| LED vang (+ qua dien tro 220R) | PA2; cuc (-) LED xuong GND |
| LED do (+ qua dien tro 220R) | PA3; cuc (-) LED xuong GND |
| Buzzer dieu khien qua transistor NPN | PB11 -> dien tro 1k -> B (base) |
| CH340 RXD | PA9 (USART1 TX) |
| CH340 TXD (neu dung) | PA10 (USART1 RX) |
| CH340 GND | GND chung |

**Quan trong voi buzzer:** Neu dung buzzer active 3.3V/5V, noi cuc (+) buzzer
den nguon phu hop; cuc (-) buzzer den collector NPN; emitter NPN den GND;
base NPN nhan tin hieu PB11 qua 1k. NEU buzzer la loai co cuon day,
kiem tra can diode chong dien ap nguoc. So do buzzer trong bao cao con
diem can kiem tra, khong duoc dau theo so do khi chua doi chieu thuc te.

XSHUT va GPIO1 cua VL53L0X khong can noi de chay ban demo. I2C phai co
pull-up len **3.3V** (module co the da co san; khong dau pull-up len 5V).

## 3. Cau hinh CubeMX va Keil

1. Chon STM32F103C8Tx/STM32F103C8T6 theo board thuc te.
2. I2C1 `PB6/PB7`, 100 kHz; USART1 `PA9/PA10`, 115200, 8N1.
3. Co the giu lai clock ban `main(5).c`: HSI/2 x 16 = 64 MHz.
4. `main.c` trong goi duoc sua tu file CubeMX cua ban **chi trong USER CODE**.
   Sao luu `main.c` hien tai truoc khi chep de co the quay lai.
5. Chep cac file `.h` (tru `test_stubs`) vao `Core/Inc` hoac thu muc header
   ma project Keil da khai bao include path.
6. Chep cac file `.c` vao `Core/Src`, thay `main.c` bang file duoc cung cap.
7. Trong Keil, vao `Project > Manage > Project Items`, them `vl53l0x.c`,
   `ssd1306.c`, `warning.c` vao nhom ma nguon. **Chi them file .c mot lan**.
8. `main.c` se tu cau hinh PA1, PA2, PA3, PB11 trong `App_IO_Init()`, nen
   ngay ca khi CubeMX chua gan GPIO output, bo demo van co the chay. Neu
   sau nay ban cau hinh GPIO bang CubeMX, hay bo phan khoi tao trung lap
   hoac giu nhat quan che do/output active-high.
9. Build, nap bang ST-Link V2, mo Hercules dung COM cua CH340 (truoc ban
   da dung COM6), 115200, 8-N-1, no flow control.

## 4. Duong di du lieu

`VL53L0X (mm) -> kiem tra loi/qua tam -> EMA khoang cach -> toc do -> TTC
-> SAFE / WARNING / CRITICAL / NO TARGET / FAULT -> OLED, LED, buzzer, Hercules`

Mau moi `200 ms` (thoi gian thuc duoc tinh bang HAL_GetTick). OLED duoc
cap nhat hang giay; UART moi 500 ms. Single-shot ranging va OLED I2C
blocking nen chu ky thuc co the lech, nhung phep tinh van dung `dt` do duoc.

**Quy uoc toc do:** duong la vat can dang tien lai gan (`distance` giam);
am la vat can dang roi xa. Neu toc do dong <= 50 mm/s, TTC = `--`.

## 5. Nguong canh bao mac dinh (CHU DONG TU CHON de demo)

| Trang thai | Dieu kien | Phan hoi |
| --- | --- | --- |
| SAFE | Khong thuoc cac muc ben duoi | LED xanh sang, buzzer tat |
| WARNING | Khoang cach <= 60 cm HOAC TTC <= 3.5 s | LED vang nhay cham, beep ngan |
| CRITICAL | Khoang cach <= 20 cm HOAC TTC <= 1.5 s | LED do nhay nhanh, buzzer lien tuc |
| NO TARGET | I2C doc thanh cong nhung mm > 2000 (vd 8190/8191) | LED xanh sang, buzzer tat, hien thi NO TARGET |
| SENSOR FAULT | Loi I2C, timeout, hoac gia tri mm < 20 | LED do nhay bao loi, buzzer beep ngan, OLED bao loi |

**Chu y:** NO TARGET la quy tac thuc hanh **uoc luong** theo gia tri mm, CHUA
duoc xac minh bang `RangeStatus` tu ST API. Den xanh trong NO TARGET
chi co nghia "khong phat hien nguy co trong cua so do"; khong bao dam
phia truoc thuc su khong co vat can.

Co the sua nguong trong `warning.h`. Day la nguong demo va chua qua
hieu chuan thuc nghiem, **khong phai nguong an toan giao thong**.

## 6. Vi du ket qua Hercules

```
STM32F103 COLLISION WARNING DEMO
[OK] OLED SSD1306
[OK] VL53L0X initialized
D=70.4cm | V=+0.0cm/s | TTC=-- | SAFE
D=52.6cm | V=+9.5cm/s | TTC=5.5s | WARNING
D=16.2cm | V=+25.0cm/s | TTC=0.6s | CRITICAL
[NO TARGET] beyond demo range; raw=8190mm, status=0x58
```

Gia tri **MINH HOA**; khong phai output da do tren bo mach cua ban.
Byte `status=...` trong thong bao NO TARGET/FAULT la byte thiet bi,
khong phai ma `RangeStatus` da duoc ST API xu ly.

## 7. Thu nghiem tung buoc

1. Thao 3 LED/buzzer neu chua chac chan mach, chi thu UART va VL53L0X.
2. Kiem tra `[OK] VL53L0X initialized`; neu FAIL, doc thong bao `step`.
3. Dat mat phang o cac moc 20, 30, 50, 70, 100 cm va ghi sai so.
4. Noi OLED va xac minh `[OK] OLED SSD1306`; neu khong co ACK, thu dia
   chi 7-bit `0x3D` (mac dinh `0x3C`) neu module cua ban ho tro.
5. Noi tung LED qua dien tro, kiem tra SAFE/WARNING/CRITICAL.
6. Lap buzzer NPN dung ky thuat, kiem tra canh bao theo nguong.
7. Di chuyen mat phang lai gan va ra xa de xem dau toc do va TTC.
8. Rut SDA cam bien de kiem tra `SENSOR FAULT` (ngat nguon truoc khi thao
   dau noi neu co nguy co cham chap).

## 8. Gioi han quan trong

- Chua su dung ST `VL53L0X_GetRangingMeasurementData()` va **chua chuyen
  raw status thanh RangeStatus**. Viec chi kiem tra gia tri mm KHONG DU
  de phan biet chac chan cam bien mat muc tieu va phep do hong. Khi lam
  san pham canh bao an toan, phai dung ST API va kiem tra `RangeStatus`.
- Driver VL53L0X nho hien tai cho muc dich thuc hanh, su dung mot so
  trinh tu khoi tao/"tuning" tham khao ST va thu vien Pololu. Chua co
  buoc kiem tra sigma, signal rate, cross-talk, offset calibration du.
- Thuat toan van toc/TTC gia su vat can dung theo truc do cua cam bien,
  do do khong suy ra van toc thuc cua xe hay duoc dung de ra quyet dinh
  an toan. Mat vat can hay muc sang choi co the gay do sai.
- Neu muon nang cap dung trong nghien cuu chinh quy: port API `STSW-IMG005`,
  loai bo mau invalid theo `RangeStatus`, hieu chuan va thu nghiem HIL,
  sau do moi tich hop FreeRTOS + Task + Queue.

Nguon tham khao:

- ST STSW-IMG005: https://www.st.com/en/embedded-software/stsw-img005.html
- ST UM2039: https://www.st.com/resource/en/user_manual/um2039-world-smallest-timeofflight-ranging-and-gesture-detection-sensor-application-programming-interface-stmicroelectronics.pdf
- ST UM2046: https://www.st.com/resource/en/user_manual/um2046-getting-started-with-vl53l0x-ranging-and-gesture-detection-sensor-software-expansion-for-stm32cube-stmicroelectronics.pdf
- Pololu's VL53L0X library (MIT license): https://github.com/pololu/vl53l0x-arduino
